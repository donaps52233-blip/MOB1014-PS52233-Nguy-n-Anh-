package com.fpoly.lab5;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TimKiemLaptop {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            List<Laptop> list = new ArrayList<>();
            
            // Du lieu mau
            list.add(new Laptop("LT01", "Dell Inspiron 15",
                    "Van phong", 15500000, 10));
            list.add(new Laptop("LT02", "Asus TUF Gaming F15",
                    "Gaming", 22990000, 5));
            list.add(new Laptop("LT03", "MacBook Air M2",
                    "Van phong", 24990000, 8));
            list.add(new Laptop("LT04", "Lenovo Legion 5",
                    "Gaming", 32500000, 0));
            list.add(new Laptop("LT05", "HP Pavilion 14",
                    "Van phong", 17800000, 0));
            
            // Tim laptop theo khoang gia
            System.out.print("Nhap gia min: ");
            double min = Double.parseDouble(sc.nextLine());
            
            System.out.print("Nhap gia max: ");
            double max = Double.parseDouble(sc.nextLine());
            
            if (min > max) {
                System.out.println("Khoang gia khong hop le");
            } else {
                System.out.println("\n=== LAPTOP GIA TU "
                        + String.format("%.0f", min) + " DEN "
                        + String.format("%.0f", max) + " ===");
                
                boolean timThay = false;
                
                for (Laptop laptop : list) {
                    if (laptop.getPrice() >= min
                            && laptop.getPrice() <= max) {
                        laptop.output();
                        timThay = true;
                    }
                }
                
                if (!timThay) {
                    System.out.println("Khong tim thay laptop nao");
                }
            }
            
            // Tim laptop theo ID hoac ten
            System.out.print("\nNhap tu khoa tim kiem: ");
            String keyword = sc.nextLine().trim();
            
            System.out.println("\n=== KET QUA TIM KIEM \""
                    + keyword + "\" ===");
            
            boolean timThay = false;
            String tuKhoaThuong = keyword.toLowerCase();
            
            for (Laptop laptop : list) {
                if (laptop.getId().equalsIgnoreCase(keyword)
                        || laptop.getName().toLowerCase()
                                .contains(tuKhoaThuong)) {
                    laptop.output();
                    timThay = true;
                }
            }

            if (!timThay) {
                System.out.println("Khong tim thay laptop nao");
            }
        }
    }
}