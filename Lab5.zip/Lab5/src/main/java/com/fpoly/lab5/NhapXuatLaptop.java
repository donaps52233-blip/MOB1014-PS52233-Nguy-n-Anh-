package com.fpoly.lab5;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NhapXuatLaptop {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            List<Laptop> list = new ArrayList<>();
            String tiepTuc;
            
            do {
                Laptop laptop = new Laptop();
                laptop.input(sc);
                list.add(laptop);
                
                System.out.print("Tiep tuc nhap? (y/n): ");
                tiepTuc = sc.nextLine();
                
            } while (tiepTuc.equalsIgnoreCase("y"));
            
            System.out.println("\n=== DANH SACH LAPTOP ("
                    + list.size() + " may) ===");
            
            for (Laptop laptop : list) {
                laptop.output();
            }
        }
    }
}