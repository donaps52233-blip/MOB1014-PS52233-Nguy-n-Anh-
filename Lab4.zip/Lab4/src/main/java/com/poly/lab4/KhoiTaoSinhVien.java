/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poly.lab4;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class KhoiTaoSinhVien {
    public static void main(String[] args) {
        // 1. Tạo sv1 bằng hàm tạo có tham số
        try (Scanner sc = new Scanner(System.in)) {
            // 1. Tạo sv1 bằng hàm tạo có tham số
            Student sv1 = new Student(
                    "PS001",
                    "Nguyen Van An",
                    19,
                    8.25
            );
            
            sv1.output();
            
            // 2. Tạo sv2 bằng hàm tạo không tham số
            Student sv2 = new Student();
            
            // Xuất ngay để quan sát giá trị mặc định
            System.out.println("\n=== SV2 TRUOC KHI NHAP ===");
            sv2.output();
            
            // Nhập thông tin sv2
            System.out.println("\n=== NHAP THONG TIN SV2 ===");
            sv2.input(sc);
            
            // Xuất lại sau khi nhập
            System.out.println("\n=== SV2 SAU KHI NHAP ===");
            sv2.output();
        }
    }
}
