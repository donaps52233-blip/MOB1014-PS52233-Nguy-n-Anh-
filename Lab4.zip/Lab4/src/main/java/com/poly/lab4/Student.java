/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poly.lab4;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Student {
    public String id;
    public String name;
    public int age;
    public double gpa;

    // Hàm tạo không tham số
    public Student() {
    }

    // Hàm tạo có tham số
    public Student(String id, String name, int age, double gpa) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gpa = gpa;
    }

    public void input(Scanner sc) {
        System.out.print("Nhap ID: ");
        id = sc.nextLine();

        System.out.print("Nhap ho ten: ");
        name = sc.nextLine();

        System.out.print("Nhap tuoi: ");
        age = Integer.parseInt(sc.nextLine());

        System.out.print("Nhap GPA: ");
        gpa = Double.parseDouble(sc.nextLine());
    }

    public String rank() {
        if (gpa >= 9.0) {
            return "XuatSac";
        } else if (gpa >= 8.0) {
            return "Gioi";
        } else if (gpa >= 6.5) {
            return "Kha";
        } else if (gpa >= 5.0) {
            return "TrungBinh";
        } else {
            return "Fail";
        }
    }

    public void output() {
        System.out.printf(
            "ID: %s | Ho ten: %s | Tuoi: %d | GPA: %.2f | Xep loai: %s%n",
            id, name, age, gpa, rank()
        );
    }
}