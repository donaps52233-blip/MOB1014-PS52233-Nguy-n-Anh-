/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poly.lab4;

/**
 *
 * @author ADMIN
 */
public class Lab4 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
