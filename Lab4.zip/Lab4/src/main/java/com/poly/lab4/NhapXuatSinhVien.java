/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poly.lab4;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class NhapXuatSinhVien {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            Student sv1 = new Student();
            Student sv2 = new Student();
            
            System.out.println("=== NHAP SINH VIEN 1 ===");
            sv1.input(sc);
            
            System.out.println("\n=== NHAP SINH VIEN 2 ===");
            sv2.input(sc);
            
            System.out.println("\n=== THONG TIN SINH VIEN ===");
            sv1.output();
            sv2.output();
            
            // Quan sát biến tham chiếu
            Student sv3 = sv1;
            sv3.name = "Test";
            
            System.out.println("\n=== SAU KHI THAY DOI sv3.name ===");
            sv1.output();
        }
    }
}
