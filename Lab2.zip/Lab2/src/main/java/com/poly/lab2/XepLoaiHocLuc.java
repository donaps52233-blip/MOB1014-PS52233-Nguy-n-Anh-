/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.poly.lab2;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;

public class XepLoaiHocLuc {
    public static void main(String[] args) {
        // Nhap diem
        try (Scanner sc = new Scanner(System.in)) {
            // Nhap diem
            System.out.print("Nhap diem Toan: ");
            double toan = sc.nextDouble();
            
            System.out.print("Nhap diem Ly: ");
            double ly = sc.nextDouble();
            
            System.out.print("Nhap diem Hoa: ");
            double hoa = sc.nextDouble();
            
            // Kiem tra diem hop le
            if (toan < 0 || toan > 10
                    || ly < 0 || ly > 10
                    || hoa < 0 || hoa > 10) {
                System.out.println("Diem khong hop le");
                return;
            }
            
            // Tinh diem trung binh
            double dtb = (toan * 2 + ly + hoa) / 4;
            
            // Xep loai
            String xepLoai;
            
            if (dtb >= 8.0) {
                xepLoai = "Gioi";
            } else if (dtb >= 6.5) {
                xepLoai = "Kha";
            } else if (dtb >= 5.0) {
                xepLoai = "Trung binh";
            } else {
                xepLoai = "Yeu";
            }
            
            // Xuat ket qua
            System.out.printf("Diem trung binh: %.2f%n", dtb);
            System.out.println("Xep loai: " + xepLoai);
        }
    }
}
