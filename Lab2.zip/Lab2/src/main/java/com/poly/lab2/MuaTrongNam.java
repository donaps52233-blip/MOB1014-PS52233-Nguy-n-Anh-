/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.poly.lab2;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;

public class MuaTrongNam {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Nhap thang: ");
            int thang = sc.nextInt();
            
            switch (thang) {
                case 1, 2, 3 -> System.out.println("Thang " + thang + ": Mua xuan");
                case 4, 5, 6 -> System.out.println("Thang " + thang + ": Mua ha");
                case 7, 8, 9 -> System.out.println("Thang " + thang + ": Mua thu");
                    
                case 10, 11, 12 -> System.out.println("Thang " + thang + ": Mua dong");
                default -> System.out.println("Thang khong hop le");
            }
        }
    }
}
