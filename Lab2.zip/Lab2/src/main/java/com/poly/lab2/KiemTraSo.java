/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.poly.lab2;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;

public class KiemTraSo {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Nhap n: ");
            int n = sc.nextInt();
            
            if (n % 2 == 0) {
                System.out.println(n + " la so chan");
            } else {
                System.out.println(n + " la so le");
            }
            
            if (n > 0) {
                System.out.println(n + " la so duong");
            } else if (n < 0) {
                System.out.println(n + " la so am");
            } else {
                System.out.println(n + " bang 0");
            }
        }
    }
}
