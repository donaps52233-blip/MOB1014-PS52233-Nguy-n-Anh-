/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.poly.lab2;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;

public class MayTinh {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Nhap a: ");
            double a = sc.nextDouble();
            
            System.out.print("Nhap b: ");
            double b = sc.nextDouble();
            
            System.out.print("Nhap phep toan (+, -, *, /): ");
            char op = sc.next().charAt(0);
            
            double ketQua;
            
            switch (op) {
                case '+' -> {
                    ketQua = a + b;
                    System.out.printf("%.2f + %.2f = %.2f%n", a, b, ketQua);
                }
                    
                case '-' -> {
                    ketQua = a - b;
                    System.out.printf("%.2f - %.2f = %.2f%n", a, b, ketQua);
                }
                    
                case '*' -> {
                    ketQua = a * b;
                    System.out.printf("%.2f * %.2f = %.2f%n", a, b, ketQua);
                }
                    
                case '/' -> {
                    if (b == 0) {
                        System.out.println("Khong the chia cho 0");
                    } else {
                        ketQua = a / b;
                        System.out.printf("%.2f / %.2f = %.2f%n", a, b, ketQua);
                    }
                }
                    
                default -> System.out.println("Phep toan khong hop le");
            }
        }
    }
}
