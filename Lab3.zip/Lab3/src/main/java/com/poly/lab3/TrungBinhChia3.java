package com.poly.lab3;

import java.util.Scanner;

public class TrungBinhChia3 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Nhap n: ");
            int n = sc.nextInt();
            
            // Kiem tra n co phai so nguyen duong
            if (n <= 0) {
                System.out.println("n phai la so nguyen duong");
                return;
            }
            
            int tong = 0;
            int dem = 0;
            
            System.out.print("Cac so chia het cho 3: ");
            
            // Duyet cac so tu 1 den n
            for (int i = 1; i <= n; i++) {
                if (i % 3 == 0) {
                    System.out.print(i + " ");
                    tong += i;
                    dem++;
                }
            }
            
            System.out.println();
            
            // Kiem tra co so nao chia het cho 3 hay khong
            if (dem == 0) {
                System.out.println("Khong co so nao chia het cho 3");
            } else {
                double trungBinh = (double) tong / dem;
                
                System.out.println("Tong: " + tong);
                System.out.printf("Trung binh cong: %.2f%n", trungBinh);
            }
        }
    }
}