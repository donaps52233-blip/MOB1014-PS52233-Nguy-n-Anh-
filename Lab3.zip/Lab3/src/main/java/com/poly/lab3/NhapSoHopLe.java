package com.poly.lab3;

import java.util.Scanner;

public class NhapSoHopLe {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int so;
            int soLan = 0;
            
            do {
                System.out.print("Nhap so: ");
                so = scanner.nextInt();
                soLan++;
                
                if (!(so > 0 && so % 3 == 0 && so % 5 == 0)) {
                    System.out.println("So khong hop le, moi nhap lai!");
                }
                
            } while (!(so > 0 && so % 3 == 0 && so % 5 == 0));
            
            System.out.println("So hop le: " + so + " (sau " + soLan + " lan nhap)");
        }
    }
}
