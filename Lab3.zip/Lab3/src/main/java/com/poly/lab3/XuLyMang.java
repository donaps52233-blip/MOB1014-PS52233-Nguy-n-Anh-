package com.poly.lab3;

import java.util.Scanner;

public class XuLyMang {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int n;
            
            // Nhập n, bắt buộc n > 0
            do {
                System.out.print("Nhap so phan tu n: ");
                n = scanner.nextInt();
            } while (n <= 0);
            
            // Khai báo mảng
            int[] a = new int[n];
            
            // Nhập từng phần tử bằng for
            for (int i = 0; i < a.length; i++) {
                System.out.print("Nhap a[" + i + "]: ");
                a[i] = scanner.nextInt();
            }
            
            // Xuất toàn bộ mảng bằng for-each
            System.out.print("Mang vua nhap: ");
            for (int x : a) {
                System.out.print(x + " ");
            }
            System.out.println();
            
            // Xuất các phần tử chẵn, dùng continue bỏ qua phần tử lẻ
            System.out.print("Cac phan tu chan: ");
            boolean coSoChan = false;
            
            for (int x : a) {
                if (x % 2 != 0) {
                    continue;
                }
                
                System.out.print(x + " ");
                coSoChan = true;
            }
            
            if (!coSoChan) {
                System.out.print("| Khong co phan tu chan");
            }
            System.out.println();
            
            // Tính tổng các phần tử chia hết cho 4
            int tong = 0;
            
            for (int x : a) {
                if (x % 4 == 0) {
                    tong += x;
                }
            }
            
            System.out.println("Tong cac so chia het cho 4: " + tong);
            
            // Tìm giá trị lớn nhất
            int max = a[0];
            
            for (int i = 1; i < a.length; i++) {
                if (a[i] > max) {
                    max = a[i];
                }
            }
            
            System.out.println("Gia tri lon nhat: " + max);
        }
    }
}
