package com.poly.lab3;

import java.util.Arrays;
import java.util.Scanner;

public class TimKiemSapXep {
    public static void main(String[] args) {
        // Nhập số phần tử n
        try (Scanner scanner = new Scanner(System.in)) {
            // Nhập số phần tử n
            int n;
            do {
                System.out.print("Nhap so phan tu n: ");
                n = scanner.nextInt();
            } while (n <= 0);
            // Khai báo và nhập mảng
            int[] a = new int[n];
            for (int i = 0; i < a.length; i++) {
                System.out.print("Nhap a[" + i + "]: ");
                a[i] = scanner.nextInt();
            }   // Nhập x
            System.out.print("Nhap x: ");
            int x = scanner.nextInt();
            // Tìm kiếm tuyến tính
            System.out.print("Vi tri cua " + x + " trong mang: ");
            boolean timThay = false;
            for (int i = 0; i < a.length; i++) {
                if (a[i] == x) {
                    System.out.print(i + " ");
                    timThay = true;
                }
            }   if (!timThay) {
                System.out.print("| Khong tim thay");
            }   System.out.println();
            // Bubble Sort giảm dần
            // Sắp xếp trực tiếp trên mảng a
            for (int i = 0; i < a.length - 1; i++) {
                for (int j = 0; j < a.length - 1 - i; j++) {
                    if (a[j] < a[j + 1]) {
                        int temp = a[j];
                        a[j] = a[j + 1];
                        a[j + 1] = temp;
                    }
                }
            }   System.out.println("Mang giam dan (Bubble Sort): " + Arrays.toString(a));
            // Tạo bản sao của mảng ban đầu
            // Lưu ý: Vì a đã bị Bubble Sort nên cần tạo bản sao
            // trước khi sắp xếp nếu muốn giữ đúng mảng ban đầu.
            //
            // Do đó, cách làm chuẩn là tạo lại từ mảng ban đầu.
            // Phần này được thực hiện ở phiên bản bên dưới.
        }
    }
}
