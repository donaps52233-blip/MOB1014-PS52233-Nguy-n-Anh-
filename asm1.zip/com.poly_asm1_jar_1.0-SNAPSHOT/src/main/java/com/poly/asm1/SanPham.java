package com.poly.asm1;

import java.util.Scanner;

public class SanPham {

    // Dung chung Scanner de tranh tao nhieu Scanner cho System.in
    public static final Scanner sc = new Scanner(System.in);

    // Thuoc tinh san pham
    public String maSP;
    public String tenSP;
    public double donGia;
    public int soLuong;

    // Constructor khong tham so
    public SanPham() {
    }

    // Constructor co tham so
    public SanPham(String maSP, String tenSP, double donGia, int soLuong) {
        this.maSP = maSP;
        this.tenSP = tenSP;
        this.donGia = donGia;
        this.soLuong = soLuong;
    }

    // Y1: Nhap thong tin san pham
    public void Nhap() {

        // Kiem tra ma san pham co dang SPXXX
        while (true) {
            System.out.print("Nhap ma san pham (SPXXX): ");
            maSP = sc.nextLine().trim();

            if (maSP.matches("SP\\d{3}")) {
                break;
            }

            System.out.println("Ma san pham khong hop le!");
            System.out.println("Vi du: SP001");
        }

        System.out.print("Nhap ten san pham: ");
        tenSP = sc.nextLine();

        // Kiem tra don gia
        while (true) {
            try {
                System.out.print("Nhap don gia: ");
                donGia = Double.parseDouble(sc.nextLine());

                if (donGia >= 0) {
                    break;
                }

                System.out.println("Don gia phai >= 0!");

            } catch (NumberFormatException e) {
                System.out.println("Don gia phai la so!");
            }
        }

        // Kiem tra so luong
        while (true) {
            try {
                System.out.print("Nhap so luong: ");
                soLuong = Integer.parseInt(sc.nextLine());

                if (soLuong >= 0) {
                    break;
                }

                System.out.println("So luong phai >= 0!");

            } catch (NumberFormatException e) {
                System.out.println("So luong phai la so nguyen!");
            }
        }
    }

    // Y2: Xuat thong tin san pham
    public void Xuat() {
        System.out.println("----------------------------------");
        System.out.println("Ma san pham: " + maSP);
        System.out.println("Ten san pham: " + tenSP);
        System.out.printf("Don gia: %.2f%n", donGia);
        System.out.println("So luong: " + soLuong);
        System.out.printf("Thanh tien: %.2f%n", thanhTien());
        System.out.println("----------------------------------");
    }

    // Y3: Tinh thanh tien = so luong * don gia
    public double thanhTien() {
        return soLuong * donGia;
    }

    // Y4: Cap nhat thong tin san pham
    public void capNhat() {

        System.out.println("Cap nhat san pham: " + maSP);

        System.out.print("Nhap ten san pham moi: ");
        tenSP = sc.nextLine();

        while (true) {
            try {
                System.out.print("Nhap don gia moi: ");
                double giaMoi = Double.parseDouble(sc.nextLine());

                if (giaMoi >= 0) {
                    donGia = giaMoi;
                    break;
                }

                System.out.println("Don gia phai >= 0!");

            } catch (NumberFormatException e) {
                System.out.println("Don gia phai la so!");
            }
        }

        while (true) {
            try {
                System.out.print("Nhap so luong moi: ");
                int soLuongMoi = Integer.parseInt(sc.nextLine());

                if (soLuongMoi >= 0) {
                    soLuong = soLuongMoi;
                    break;
                }

                System.out.println("So luong phai >= 0!");

            } catch (NumberFormatException e) {
                System.out.println("So luong phai la so nguyen!");
            }
        }

        System.out.println("Cap nhat thanh cong!");
    }
}

