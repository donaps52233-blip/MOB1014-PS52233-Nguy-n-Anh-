package com.poly.asm1;

import java.util.ArrayList;

public class Asm1 {

    public static void main(String[] args) {

        ArrayList<SanPham> danhSach = new ArrayList<>();

        int chon;

        do {
            System.out.println();
            System.out.println("========== QUAN LY SAN PHAM ==========");
            System.out.println("1. Them san pham");
            System.out.println("2. Xem danh sach san pham");
            System.out.println("3. Cap nhat san pham");
            System.out.println("0. Thoat");
            System.out.println("======================================");

            System.out.print("Chon chuc nang: ");

            try {
                chon = Integer.parseInt(SanPham.sc.nextLine());
            } catch (NumberFormatException e) {
                chon = -1;
            }

            switch (chon) {

                case 1 -> {
                    // Them san pham
                    SanPham sp = new SanPham();
                    sp.Nhap();

                    // Kiem tra ma san pham trung
                    boolean trungMa = false;

                    for (SanPham item : danhSach) {
                        if (item.maSP.equalsIgnoreCase(sp.maSP)) {
                            trungMa = true;
                            break;
                        }
                    }

                    if (trungMa) {
                        System.out.println("Ma san pham da ton tai!");
                    } else {
                        danhSach.add(sp);
                        System.out.println("Them san pham thanh cong!");
                    }
                }

                case 2 -> {
                    // Xem danh sach san pham
                    if (danhSach.isEmpty()) {
                        System.out.println("Chua co san pham nao!");
                    } else {
                        System.out.println("===== DANH SACH SAN PHAM =====");

                        for (SanPham item : danhSach) {
                            item.Xuat();
                        }
                    }
                }

                case 3 -> {
                    // Cap nhat san pham theo ma
                    System.out.print("Nhap ma san pham can cap nhat: ");
                    String maCanTim = SanPham.sc.nextLine().trim();

                    SanPham spCanSua = null;

                    for (SanPham item : danhSach) {
                        if (item.maSP.equalsIgnoreCase(maCanTim)) {
                            spCanSua = item;
                            break;
                        }
                    }

                    if (spCanSua == null) {
                        System.out.println("Khong tim thay san pham!");
                    } else {
                        spCanSua.capNhat();
                    }
                }

                case 0 -> System.out.println("Ket thuc chuong trinh!");

                default -> System.out.println("Lua chon khong hop le!");
            }

        } while (chon != 0);
    }
}

