/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poly.lab1;

/**
 *
 * @author ADMIN
 */
public class HelloJava {
   public static void main(String[] args) {
        System.out.println("Ho va ten: Nguyen Anh Do \n MSSV: PS52233");
}
}
