/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poly.lab1;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class HinhChuNhat {
        public static void main(String[] args) {      
        Scanner sc = new Scanner(System.in);
        final double PI = 3.14;
        
        System.out.print("Nhap chieu dai: ");
        double chieudai = sc.nextDouble();
        
        System.out.print("Nhap chieu rong: ");
        double chieurong = sc.nextDouble();
        
        double chuvi = 2* (chieudai + chieurong);
        double dientich = chieudai + chieurong;
        
        System.out.println("Chu vi hinh chu nhat =" +chuvi);
            System.out.println("Dien tich hinh chu nhat =" +dientich);
        sc.close();
    }   
}
